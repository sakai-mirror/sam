alter table SAM_ASSESSMENTGRADING_T alter column SUBMITTEDDATE datetime null;
commit;