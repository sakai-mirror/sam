alter table SAM_MEDIA_T add column (DURATION varchar(36));
