alter table SAM_ITEMGRADING_T modify (SUBMITTEDDATE date null);
commit;
